﻿namespace WeddingPlannerApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button39 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button23 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.btnDjSound = new System.Windows.Forms.Button();
            this.btnPhotoVideographer = new System.Windows.Forms.Button();
            this.btnCelebrityPerform = new System.Windows.Forms.Button();
            this.btnLiveBand = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.Backbtn = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.PBSuites3 = new System.Windows.Forms.PictureBox();
            this.PBSuites2 = new System.Windows.Forms.PictureBox();
            this.PBSuites1 = new System.Windows.Forms.PictureBox();
            this.PBShoes3 = new System.Windows.Forms.PictureBox();
            this.PBShoes2 = new System.Windows.Forms.PictureBox();
            this.PBShoes1 = new System.Windows.Forms.PictureBox();
            this.PBAccessories3 = new System.Windows.Forms.PictureBox();
            this.PBAccessories2 = new System.Windows.Forms.PictureBox();
            this.PBAccessories1 = new System.Windows.Forms.PictureBox();
            this.PBGown3 = new System.Windows.Forms.PictureBox();
            this.PBGown2 = new System.Windows.Forms.PictureBox();
            this.PBGown1 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBSuites3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSuites2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSuites1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBShoes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBShoes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBShoes1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAccessories3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAccessories2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAccessories1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBGown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBGown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBGown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SeaShell;
            this.panel1.Controls.Add(this.button39);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(170, 563);
            this.panel1.TabIndex = 0;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.SeaShell;
            this.button39.Font = new System.Drawing.Font("Microsoft Uighur", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.ForeColor = System.Drawing.Color.Tomato;
            this.button39.Location = new System.Drawing.Point(0, 3);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(172, 76);
            this.button39.TabIndex = 14;
            this.button39.Text = "Services";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button5.Font = new System.Drawing.Font("Rockwell", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(0, 484);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(169, 75);
            this.button5.TabIndex = 2;
            this.button5.Text = "Schedule";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.ScheduleButton);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button4.Font = new System.Drawing.Font("Rockwell", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(0, 392);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(169, 75);
            this.button4.TabIndex = 2;
            this.button4.Text = "Decor";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.DecorButton);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button2.Font = new System.Drawing.Font("Rockwell", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(3, 201);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 75);
            this.button2.TabIndex = 2;
            this.button2.Text = "Menu";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.MenuButton);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button3.Font = new System.Drawing.Font("Rockwell", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(3, 298);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(169, 75);
            this.button3.TabIndex = 3;
            this.button3.Text = "Media";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.MediaButton);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.button1.Font = new System.Drawing.Font("Rockwell", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(0, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(169, 75);
            this.button1.TabIndex = 1;
            this.button1.Text = "Attire";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.AttireButton);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(168, 32);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(687, 531);
            this.tabControl1.TabIndex = 1;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.button23);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button10);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.button8);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(679, 502);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Attire";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.PBSuites3);
            this.panel3.Controls.Add(this.PBSuites2);
            this.panel3.Controls.Add(this.PBSuites1);
            this.panel3.Location = new System.Drawing.Point(215, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(455, 81);
            this.panel3.TabIndex = 10;
            this.panel3.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.PBShoes3);
            this.panel4.Controls.Add(this.PBShoes2);
            this.panel4.Controls.Add(this.PBShoes1);
            this.panel4.Location = new System.Drawing.Point(215, 291);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(455, 77);
            this.panel4.TabIndex = 10;
            this.panel4.Visible = false;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.PBAccessories3);
            this.panel5.Controls.Add(this.PBAccessories2);
            this.panel5.Controls.Add(this.PBAccessories1);
            this.panel5.Location = new System.Drawing.Point(215, 396);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(455, 77);
            this.panel5.TabIndex = 10;
            this.panel5.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.PBGown3);
            this.panel2.Controls.Add(this.PBGown2);
            this.panel2.Controls.Add(this.PBGown1);
            this.panel2.Location = new System.Drawing.Point(215, 77);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(455, 77);
            this.panel2.TabIndex = 9;
            this.panel2.Visible = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.MistyRose;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.Black;
            this.button23.Location = new System.Drawing.Point(0, 0);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(102, 63);
            this.button23.TabIndex = 8;
            this.button23.Text = "BACK";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.BackButton1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SeaShell;
            this.label1.Font = new System.Drawing.Font("Microsoft Uighur", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Tomato;
            this.label1.Location = new System.Drawing.Point(277, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 72);
            this.label1.TabIndex = 5;
            this.label1.Text = "Attires";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.MistyRose;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.Location = new System.Drawing.Point(577, 0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(102, 63);
            this.button10.TabIndex = 4;
            this.button10.Text = "SAVE";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.SaveButton1);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.MistyRose;
            this.button9.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Tomato;
            this.button9.Location = new System.Drawing.Point(7, 396);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(202, 77);
            this.button9.TabIndex = 3;
            this.button9.Text = "Accessories";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.AccessoriesButton);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.MistyRose;
            this.button8.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Tomato;
            this.button8.Location = new System.Drawing.Point(7, 182);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(202, 81);
            this.button8.TabIndex = 2;
            this.button8.Text = "Suites";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.SuitesButton);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.MistyRose;
            this.button7.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Tomato;
            this.button7.Location = new System.Drawing.Point(7, 291);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(202, 77);
            this.button7.TabIndex = 1;
            this.button7.Text = "Shoes";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.ShoesButton);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.MistyRose;
            this.button6.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Tomato;
            this.button6.Location = new System.Drawing.Point(7, 79);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(202, 75);
            this.button6.TabIndex = 0;
            this.button6.Text = "Gowns";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.GownsButton);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage2.Controls.Add(this.panel7);
            this.tabPage2.Controls.Add(this.panel8);
            this.tabPage2.Controls.Add(this.panel9);
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Controls.Add(this.button17);
            this.tabPage2.Controls.Add(this.button15);
            this.tabPage2.Controls.Add(this.button14);
            this.tabPage2.Controls.Add(this.button13);
            this.tabPage2.Controls.Add(this.button12);
            this.tabPage2.Controls.Add(this.button11);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(679, 502);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Menu";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pictureBox9);
            this.panel7.Controls.Add(this.pictureBox8);
            this.panel7.Controls.Add(this.pictureBox7);
            this.panel7.Location = new System.Drawing.Point(196, 194);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(474, 79);
            this.panel7.TabIndex = 9;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.pictureBox12);
            this.panel8.Controls.Add(this.pictureBox11);
            this.panel8.Controls.Add(this.pictureBox10);
            this.panel8.Location = new System.Drawing.Point(196, 295);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(474, 81);
            this.panel8.TabIndex = 9;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.pictureBox15);
            this.panel9.Controls.Add(this.pictureBox14);
            this.panel9.Controls.Add(this.pictureBox13);
            this.panel9.Location = new System.Drawing.Point(196, 399);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(474, 81);
            this.panel9.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Controls.Add(this.pictureBox4);
            this.panel6.Location = new System.Drawing.Point(196, 85);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(474, 84);
            this.panel6.TabIndex = 8;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.MistyRose;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.Black;
            this.button17.Location = new System.Drawing.Point(3, 1);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(102, 63);
            this.button17.TabIndex = 7;
            this.button17.Text = "BACK";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.BackButton2);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.MistyRose;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.Black;
            this.button15.Location = new System.Drawing.Point(518, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(102, 58);
            this.button15.TabIndex = 5;
            this.button15.Text = "SAVE";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.SaveButton2);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.MistyRose;
            this.button14.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.Tomato;
            this.button14.Location = new System.Drawing.Point(7, 399);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(183, 81);
            this.button14.TabIndex = 4;
            this.button14.Text = "Beverages";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.BeveragesButton);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.MistyRose;
            this.button13.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.Tomato;
            this.button13.Location = new System.Drawing.Point(6, 295);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(183, 81);
            this.button13.TabIndex = 3;
            this.button13.Text = "Dessert";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.DessertButton);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.MistyRose;
            this.button12.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.Tomato;
            this.button12.Location = new System.Drawing.Point(7, 194);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(183, 79);
            this.button12.TabIndex = 2;
            this.button12.Text = "Mains";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.MainsButton);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.MistyRose;
            this.button11.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.Tomato;
            this.button11.Location = new System.Drawing.Point(7, 85);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(182, 84);
            this.button11.TabIndex = 1;
            this.button11.Text = "Starters";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.StartersButton);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SeaShell;
            this.label2.Font = new System.Drawing.Font("Microsoft Uighur", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Tomato;
            this.label2.Location = new System.Drawing.Point(238, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 72);
            this.label2.TabIndex = 0;
            this.label2.Text = "Menu";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage3.Controls.Add(this.panel11);
            this.tabPage3.Controls.Add(this.panel12);
            this.tabPage3.Controls.Add(this.panel13);
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Controls.Add(this.button22);
            this.tabPage3.Controls.Add(this.button21);
            this.tabPage3.Controls.Add(this.btnDjSound);
            this.tabPage3.Controls.Add(this.btnPhotoVideographer);
            this.tabPage3.Controls.Add(this.btnCelebrityPerform);
            this.tabPage3.Controls.Add(this.btnLiveBand);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(679, 502);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Media";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.pictureBox21);
            this.panel11.Controls.Add(this.pictureBox20);
            this.panel11.Controls.Add(this.pictureBox19);
            this.panel11.Location = new System.Drawing.Point(215, 189);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(455, 71);
            this.panel11.TabIndex = 9;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.pictureBox24);
            this.panel12.Controls.Add(this.pictureBox23);
            this.panel12.Controls.Add(this.pictureBox22);
            this.panel12.Location = new System.Drawing.Point(215, 296);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(455, 84);
            this.panel12.TabIndex = 9;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.pictureBox27);
            this.panel13.Controls.Add(this.pictureBox26);
            this.panel13.Controls.Add(this.pictureBox25);
            this.panel13.Location = new System.Drawing.Point(215, 405);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(455, 72);
            this.panel13.TabIndex = 9;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.pictureBox18);
            this.panel10.Controls.Add(this.pictureBox17);
            this.panel10.Controls.Add(this.pictureBox16);
            this.panel10.Location = new System.Drawing.Point(215, 88);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(455, 71);
            this.panel10.TabIndex = 9;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.MistyRose;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.Black;
            this.button22.Location = new System.Drawing.Point(0, 0);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(102, 63);
            this.button22.TabIndex = 8;
            this.button22.Text = "BACK";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.BackButton3);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.MistyRose;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.Black;
            this.button21.Location = new System.Drawing.Point(521, 0);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(102, 58);
            this.button21.TabIndex = 6;
            this.button21.Text = "SAVE";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.SaveButton3);
            // 
            // btnDjSound
            // 
            this.btnDjSound.BackColor = System.Drawing.Color.MistyRose;
            this.btnDjSound.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDjSound.ForeColor = System.Drawing.Color.Tomato;
            this.btnDjSound.Location = new System.Drawing.Point(7, 405);
            this.btnDjSound.Name = "btnDjSound";
            this.btnDjSound.Size = new System.Drawing.Size(202, 72);
            this.btnDjSound.TabIndex = 5;
            this.btnDjSound.Text = "DJ and Sound ";
            this.btnDjSound.UseVisualStyleBackColor = false;
            this.btnDjSound.Click += new System.EventHandler(this.btnDjSound_Click);
            // 
            // btnPhotoVideographer
            // 
            this.btnPhotoVideographer.BackColor = System.Drawing.Color.MistyRose;
            this.btnPhotoVideographer.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPhotoVideographer.ForeColor = System.Drawing.Color.Tomato;
            this.btnPhotoVideographer.Location = new System.Drawing.Point(7, 88);
            this.btnPhotoVideographer.Name = "btnPhotoVideographer";
            this.btnPhotoVideographer.Size = new System.Drawing.Size(202, 71);
            this.btnPhotoVideographer.TabIndex = 4;
            this.btnPhotoVideographer.Text = "Photo/Videgrapher";
            this.btnPhotoVideographer.UseVisualStyleBackColor = false;
            this.btnPhotoVideographer.Click += new System.EventHandler(this.btnPhotoVideographer_Click);
            // 
            // btnCelebrityPerform
            // 
            this.btnCelebrityPerform.BackColor = System.Drawing.Color.MistyRose;
            this.btnCelebrityPerform.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCelebrityPerform.ForeColor = System.Drawing.Color.Tomato;
            this.btnCelebrityPerform.Location = new System.Drawing.Point(7, 296);
            this.btnCelebrityPerform.Name = "btnCelebrityPerform";
            this.btnCelebrityPerform.Size = new System.Drawing.Size(202, 84);
            this.btnCelebrityPerform.TabIndex = 3;
            this.btnCelebrityPerform.Text = "Celebrity \r\nperformance";
            this.btnCelebrityPerform.UseVisualStyleBackColor = false;
            this.btnCelebrityPerform.Click += new System.EventHandler(this.btnCelebrityPerform_Click);
            // 
            // btnLiveBand
            // 
            this.btnLiveBand.BackColor = System.Drawing.Color.MistyRose;
            this.btnLiveBand.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLiveBand.ForeColor = System.Drawing.Color.Tomato;
            this.btnLiveBand.Location = new System.Drawing.Point(7, 189);
            this.btnLiveBand.Name = "btnLiveBand";
            this.btnLiveBand.Size = new System.Drawing.Size(202, 71);
            this.btnLiveBand.TabIndex = 2;
            this.btnLiveBand.Text = "Live band";
            this.btnLiveBand.UseVisualStyleBackColor = false;
            this.btnLiveBand.Click += new System.EventHandler(this.btnLiveBand_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SeaShell;
            this.label3.Font = new System.Drawing.Font("Microsoft Uighur", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Tomato;
            this.label3.Location = new System.Drawing.Point(230, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 72);
            this.label3.TabIndex = 0;
            this.label3.Text = "Media";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage4.Controls.Add(this.comboBox3);
            this.tabPage4.Controls.Add(this.comboBox2);
            this.tabPage4.Controls.Add(this.comboBox1);
            this.tabPage4.Controls.Add(this.panel15);
            this.tabPage4.Controls.Add(this.button30);
            this.tabPage4.Controls.Add(this.button29);
            this.tabPage4.Controls.Add(this.button28);
            this.tabPage4.Controls.Add(this.button34);
            this.tabPage4.Controls.Add(this.button33);
            this.tabPage4.Controls.Add(this.button31);
            this.tabPage4.Controls.Add(this.button32);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(679, 502);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Decor";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.pictureBox3);
            this.panel15.Controls.Add(this.pictureBox2);
            this.panel15.Controls.Add(this.pictureBox1);
            this.panel15.Location = new System.Drawing.Point(224, 172);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(449, 71);
            this.panel15.TabIndex = 9;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.MistyRose;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.ForeColor = System.Drawing.Color.Black;
            this.button30.Location = new System.Drawing.Point(0, 0);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(102, 55);
            this.button30.TabIndex = 11;
            this.button30.Text = "BACK";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.BackButton4);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.MistyRose;
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.ForeColor = System.Drawing.Color.Black;
            this.button29.Location = new System.Drawing.Point(521, 0);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(102, 55);
            this.button29.TabIndex = 10;
            this.button29.Text = "SAVE";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.SaveButton4);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.MistyRose;
            this.button28.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.ForeColor = System.Drawing.Color.Tomato;
            this.button28.Location = new System.Drawing.Point(4, 71);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(202, 64);
            this.button28.TabIndex = 9;
            this.button28.Text = "Colour Scheme";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.ButtonColorScheme);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.MistyRose;
            this.button34.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.ForeColor = System.Drawing.Color.Tomato;
            this.button34.Location = new System.Drawing.Point(3, 432);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(202, 64);
            this.button34.TabIndex = 8;
            this.button34.Text = "Seat Arrangements";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.SeatArrangementsButton);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.MistyRose;
            this.button33.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.ForeColor = System.Drawing.Color.Tomato;
            this.button33.Location = new System.Drawing.Point(5, 346);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(202, 64);
            this.button33.TabIndex = 7;
            this.button33.Text = "Lighting";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.LightingButton);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.MistyRose;
            this.button31.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.ForeColor = System.Drawing.Color.Tomato;
            this.button31.Location = new System.Drawing.Point(3, 172);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(202, 64);
            this.button31.TabIndex = 6;
            this.button31.Text = "Theme";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.ThemeButton);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.MistyRose;
            this.button32.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.ForeColor = System.Drawing.Color.Tomato;
            this.button32.Location = new System.Drawing.Point(3, 261);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(202, 64);
            this.button32.TabIndex = 5;
            this.button32.Text = "Table setting";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.TableSettingButton);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SeaShell;
            this.label4.Font = new System.Drawing.Font("Microsoft Uighur", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Tomato;
            this.label4.Location = new System.Drawing.Point(247, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(138, 72);
            this.label4.TabIndex = 1;
            this.label4.Text = "Decor";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.tabPage5.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage5.Controls.Add(this.dtpTime);
            this.tabPage5.Controls.Add(this.dtpDate);
            this.tabPage5.Controls.Add(this.comboBox6);
            this.tabPage5.Controls.Add(this.comboBox5);
            this.tabPage5.Controls.Add(this.comboBox4);
            this.tabPage5.Controls.Add(this.button36);
            this.tabPage5.Controls.Add(this.button35);
            this.tabPage5.Controls.Add(this.button41);
            this.tabPage5.Controls.Add(this.button40);
            this.tabPage5.Controls.Add(this.button37);
            this.tabPage5.Controls.Add(this.button38);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(679, 502);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Schedule";
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.MistyRose;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.ForeColor = System.Drawing.Color.Black;
            this.button36.Location = new System.Drawing.Point(0, 0);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(102, 55);
            this.button36.TabIndex = 15;
            this.button36.Text = "BACK";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.BackButton5);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.MistyRose;
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.ForeColor = System.Drawing.Color.Black;
            this.button35.Location = new System.Drawing.Point(577, 0);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(102, 55);
            this.button35.TabIndex = 14;
            this.button35.Text = "SAVE";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.SaveButton_Click5);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.MistyRose;
            this.button41.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.ForeColor = System.Drawing.Color.Tomato;
            this.button41.Location = new System.Drawing.Point(7, 408);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(252, 63);
            this.button41.TabIndex = 13;
            this.button41.Text = "Guest activities";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.GuestActivitiesButton);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.MistyRose;
            this.button40.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.ForeColor = System.Drawing.Color.Tomato;
            this.button40.Location = new System.Drawing.Point(7, 310);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(252, 59);
            this.button40.TabIndex = 12;
            this.button40.Text = "Reception details";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.ReceptionButton);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.MistyRose;
            this.button37.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.ForeColor = System.Drawing.Color.Tomato;
            this.button37.Location = new System.Drawing.Point(7, 90);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(252, 63);
            this.button37.TabIndex = 11;
            this.button37.Text = "Ceremony Timing";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.CeremonyTimeButton);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.MistyRose;
            this.button38.Font = new System.Drawing.Font("Microsoft Uighur", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.ForeColor = System.Drawing.Color.Tomato;
            this.button38.Location = new System.Drawing.Point(7, 190);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(252, 74);
            this.button38.TabIndex = 10;
            this.button38.Text = "Set meet-up with vendors\r\n";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.MeetingButton);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.SeaShell;
            this.label5.Font = new System.Drawing.Font("Microsoft Uighur", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Tomato;
            this.label5.Location = new System.Drawing.Point(236, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(194, 72);
            this.label5.TabIndex = 2;
            this.label5.Text = "Schedule";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.BackColor = System.Drawing.Color.SeaShell;
            this.Exitbtn.Font = new System.Drawing.Font("Microsoft Uighur", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exitbtn.ForeColor = System.Drawing.Color.Tomato;
            this.Exitbtn.Location = new System.Drawing.Point(780, 0);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(75, 35);
            this.Exitbtn.TabIndex = 2;
            this.Exitbtn.Text = "X";
            this.Exitbtn.UseVisualStyleBackColor = false;
            this.Exitbtn.Click += new System.EventHandler(this.button37_Click);
            // 
            // Backbtn
            // 
            this.Backbtn.BackColor = System.Drawing.Color.SeaShell;
            this.Backbtn.Font = new System.Drawing.Font("Microsoft Uighur", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Backbtn.ForeColor = System.Drawing.Color.Tomato;
            this.Backbtn.Location = new System.Drawing.Point(177, 0);
            this.Backbtn.Name = "Backbtn";
            this.Backbtn.Size = new System.Drawing.Size(75, 35);
            this.Backbtn.TabIndex = 3;
            this.Backbtn.Text = "Back";
            this.Backbtn.UseVisualStyleBackColor = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(224, 272);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(433, 24);
            this.comboBox1.TabIndex = 12;
            this.comboBox1.Text = "Select an option";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(224, 357);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(433, 24);
            this.comboBox2.TabIndex = 13;
            this.comboBox2.Text = "Select an option";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(224, 454);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(433, 24);
            this.comboBox3.TabIndex = 14;
            this.comboBox3.Text = "Select an option";
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(284, 427);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(361, 24);
            this.comboBox4.TabIndex = 16;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(284, 217);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(361, 24);
            this.comboBox5.TabIndex = 17;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(284, 329);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(361, 24);
            this.comboBox6.TabIndex = 18;
            // 
            // dtpDate
            // 
            this.dtpDate.Location = new System.Drawing.Point(283, 90);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(360, 22);
            this.dtpDate.TabIndex = 19;
            this.dtpDate.ValueChanged += new System.EventHandler(this.dateTimDatePicker1_ValueChange);
            // 
            // dtpTime
            // 
            this.dtpTime.Location = new System.Drawing.Point(285, 131);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.Size = new System.Drawing.Size(358, 22);
            this.dtpTime.TabIndex = 20;
            this.dtpTime.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChange);
            // 
            // PBSuites3
            // 
            this.PBSuites3.Image = global::WeddingPlannerApp.Properties.Resources.Simon_Slim_Fit_High_Quality_Shawl_Collar_Black_Tuxedo_Suıt___EU_50___US_40__UK_40___36W;
            this.PBSuites3.Location = new System.Drawing.Point(320, 0);
            this.PBSuites3.Name = "PBSuites3";
            this.PBSuites3.Size = new System.Drawing.Size(135, 81);
            this.PBSuites3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBSuites3.TabIndex = 3;
            this.PBSuites3.TabStop = false;
            // 
            // PBSuites2
            // 
            this.PBSuites2.Image = global::WeddingPlannerApp.Properties.Resources.Black_tuxedo;
            this.PBSuites2.Location = new System.Drawing.Point(161, 0);
            this.PBSuites2.Name = "PBSuites2";
            this.PBSuites2.Size = new System.Drawing.Size(132, 81);
            this.PBSuites2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBSuites2.TabIndex = 2;
            this.PBSuites2.TabStop = false;
            // 
            // PBSuites1
            // 
            this.PBSuites1.Image = global::WeddingPlannerApp.Properties.Resources.Light_Grey_Three_Piece_Suit_for_Men___Formal_Wedding__Business__or_Special_Occasions___Tailored_Suit___The_Rising_Sun_store__Vardo;
            this.PBSuites1.Location = new System.Drawing.Point(0, 0);
            this.PBSuites1.Name = "PBSuites1";
            this.PBSuites1.Size = new System.Drawing.Size(135, 81);
            this.PBSuites1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBSuites1.TabIndex = 1;
            this.PBSuites1.TabStop = false;
            // 
            // PBShoes3
            // 
            this.PBShoes3.Image = global::WeddingPlannerApp.Properties.Resources.Stay_Golden___WedLuxe_Magazine;
            this.PBShoes3.Location = new System.Drawing.Point(320, 0);
            this.PBShoes3.Name = "PBShoes3";
            this.PBShoes3.Size = new System.Drawing.Size(135, 77);
            this.PBShoes3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBShoes3.TabIndex = 4;
            this.PBShoes3.TabStop = false;
            // 
            // PBShoes2
            // 
            this.PBShoes2.Image = global::WeddingPlannerApp.Properties.Resources.Nike__I_Do__Shoes;
            this.PBShoes2.Location = new System.Drawing.Point(160, 0);
            this.PBShoes2.Name = "PBShoes2";
            this.PBShoes2.Size = new System.Drawing.Size(135, 77);
            this.PBShoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBShoes2.TabIndex = 3;
            this.PBShoes2.TabStop = false;
            // 
            // PBShoes1
            // 
            this.PBShoes1.Image = global::WeddingPlannerApp.Properties.Resources.A_Romantic_Pink_Miramonte_Resort_Wedding_in_Palm_Desert;
            this.PBShoes1.Location = new System.Drawing.Point(0, 0);
            this.PBShoes1.Name = "PBShoes1";
            this.PBShoes1.Size = new System.Drawing.Size(135, 77);
            this.PBShoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBShoes1.TabIndex = 2;
            this.PBShoes1.TabStop = false;
            // 
            // PBAccessories3
            // 
            this.PBAccessories3.Image = global::WeddingPlannerApp.Properties.Resources._1pair_Gold_Leaf_Lapel_Pin_For_Men___Women_s_Shirt___Suit__Unisex_Lover_Gift_Collar_Clips;
            this.PBAccessories3.Location = new System.Drawing.Point(320, 0);
            this.PBAccessories3.Name = "PBAccessories3";
            this.PBAccessories3.Size = new System.Drawing.Size(135, 77);
            this.PBAccessories3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAccessories3.TabIndex = 4;
            this.PBAccessories3.TabStop = false;
            // 
            // PBAccessories2
            // 
            this.PBAccessories2.Image = global::WeddingPlannerApp.Properties.Resources.Wedding___Bridal___Formal_Necklace_Set___Color__Silver___Size__Os;
            this.PBAccessories2.Location = new System.Drawing.Point(160, 0);
            this.PBAccessories2.Name = "PBAccessories2";
            this.PBAccessories2.Size = new System.Drawing.Size(135, 77);
            this.PBAccessories2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAccessories2.TabIndex = 3;
            this.PBAccessories2.TabStop = false;
            // 
            // PBAccessories1
            // 
            this.PBAccessories1.Image = global::WeddingPlannerApp.Properties.Resources.Bridal_rings_at_KAY;
            this.PBAccessories1.Location = new System.Drawing.Point(0, 0);
            this.PBAccessories1.Name = "PBAccessories1";
            this.PBAccessories1.Size = new System.Drawing.Size(135, 77);
            this.PBAccessories1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBAccessories1.TabIndex = 2;
            this.PBAccessories1.TabStop = false;
            // 
            // PBGown3
            // 
            this.PBGown3.Image = global::WeddingPlannerApp.Properties.Resources.Agatha___Ivory___10___Extra_Length;
            this.PBGown3.Location = new System.Drawing.Point(323, 1);
            this.PBGown3.Name = "PBGown3";
            this.PBGown3.Size = new System.Drawing.Size(132, 76);
            this.PBGown3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBGown3.TabIndex = 2;
            this.PBGown3.TabStop = false;
            // 
            // PBGown2
            // 
            this.PBGown2.Image = global::WeddingPlannerApp.Properties.Resources.download;
            this.PBGown2.Location = new System.Drawing.Point(161, 1);
            this.PBGown2.Name = "PBGown2";
            this.PBGown2.Size = new System.Drawing.Size(132, 76);
            this.PBGown2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBGown2.TabIndex = 1;
            this.PBGown2.TabStop = false;
            // 
            // PBGown1
            // 
            this.PBGown1.Image = global::WeddingPlannerApp.Properties.Resources._15__Brides_Who_Dared_to_Choose_a_Very_Unusual_Outfit_for_Their_Wedding_and_Stunned_Everyone;
            this.PBGown1.Location = new System.Drawing.Point(0, 0);
            this.PBGown1.Name = "PBGown1";
            this.PBGown1.Size = new System.Drawing.Size(135, 76);
            this.PBGown1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PBGown1.TabIndex = 0;
            this.PBGown1.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::WeddingPlannerApp.Properties.Resources.Best_Butter_Chicken_Recipe;
            this.pictureBox9.Location = new System.Drawing.Point(338, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(136, 79);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 3;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::WeddingPlannerApp.Properties.Resources.download__2_;
            this.pictureBox8.Location = new System.Drawing.Point(0, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(139, 79);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::WeddingPlannerApp.Properties.Resources.Afro_fusion_restaurant___Tabys_Café___Restaurant;
            this.pictureBox7.Location = new System.Drawing.Point(169, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(136, 79);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::WeddingPlannerApp.Properties.Resources.Wedding_Cake_Alternatives_Guide_for_2024___Wedding_Forward;
            this.pictureBox12.Location = new System.Drawing.Point(338, 0);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(136, 81);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 3;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::WeddingPlannerApp.Properties.Resources._34_Unique_Wedding_Food_Dessert_Table_Display_Ideas___Mrs_to_Be;
            this.pictureBox11.Location = new System.Drawing.Point(0, 0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(136, 81);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 2;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::WeddingPlannerApp.Properties.Resources.Best_Cupcake_Ideas___Kitchen_Fun_With_My_3_Sons;
            this.pictureBox10.Location = new System.Drawing.Point(169, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(136, 81);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 1;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::WeddingPlannerApp.Properties.Resources.The_Best_Wedding_Drink_Menu_Ideas;
            this.pictureBox15.Location = new System.Drawing.Point(338, 0);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(136, 81);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 3;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::WeddingPlannerApp.Properties.Resources.Wedding_drinks;
            this.pictureBox14.Location = new System.Drawing.Point(169, 0);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(136, 81);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 2;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::WeddingPlannerApp.Properties.Resources.Drinks;
            this.pictureBox13.Location = new System.Drawing.Point(0, 0);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(136, 81);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 1;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::WeddingPlannerApp.Properties.Resources.snacks;
            this.pictureBox6.Location = new System.Drawing.Point(338, 1);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(136, 83);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 2;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::WeddingPlannerApp.Properties.Resources._22_Amazing_Details_for_A_Cosy_Winter_Wedding___weddingsonline;
            this.pictureBox5.Location = new System.Drawing.Point(169, 1);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(136, 83);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WeddingPlannerApp.Properties.Resources.download__1_;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(136, 83);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Location = new System.Drawing.Point(319, 0);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(136, 71);
            this.pictureBox21.TabIndex = 3;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Location = new System.Drawing.Point(0, 0);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(136, 71);
            this.pictureBox20.TabIndex = 2;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Location = new System.Drawing.Point(159, 0);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(136, 71);
            this.pictureBox19.TabIndex = 1;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Location = new System.Drawing.Point(319, 0);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(136, 83);
            this.pictureBox24.TabIndex = 3;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Location = new System.Drawing.Point(159, 1);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(136, 83);
            this.pictureBox23.TabIndex = 2;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Location = new System.Drawing.Point(0, 0);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(139, 84);
            this.pictureBox22.TabIndex = 1;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.Location = new System.Drawing.Point(0, 0);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(136, 72);
            this.pictureBox27.TabIndex = 3;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.Location = new System.Drawing.Point(319, 0);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(136, 72);
            this.pictureBox26.TabIndex = 2;
            this.pictureBox26.TabStop = false;
            this.pictureBox26.Click += new System.EventHandler(this.pictureBox26_Click);
            // 
            // pictureBox25
            // 
            this.pictureBox25.Location = new System.Drawing.Point(159, 0);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(136, 72);
            this.pictureBox25.TabIndex = 1;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WeddingPlannerApp.Properties.Resources.Pink_Dreams__16_Stylish_Ideas_for_a_Pink_Wedding;
            this.pictureBox3.Location = new System.Drawing.Point(337, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(112, 70);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WeddingPlannerApp.Properties.Resources._9_Enchanting_Spring_Wedding_Themes__Inspiring_Color_Ideas__Decor__Favors__and_More;
            this.pictureBox2.Location = new System.Drawing.Point(169, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 70);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WeddingPlannerApp.Properties.Resources._10_Best_Spring_Wedding_Color_Palette_Ideas_To_Help_Inspire_You_For_Your_Special_Day___Francisca_s_Bridal;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Location = new System.Drawing.Point(319, 0);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(136, 71);
            this.pictureBox18.TabIndex = 3;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Location = new System.Drawing.Point(0, 0);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(139, 71);
            this.pictureBox17.TabIndex = 2;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Location = new System.Drawing.Point(159, 0);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(136, 71);
            this.pictureBox16.TabIndex = 1;
            this.pictureBox16.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(854, 567);
            this.Controls.Add(this.Backbtn);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBSuites3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSuites2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBSuites1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBShoes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBShoes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBShoes1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAccessories3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAccessories2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBAccessories1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBGown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBGown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBGown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDjSound;
        private System.Windows.Forms.Button btnPhotoVideographer;
        private System.Windows.Forms.Button btnCelebrityPerform;
        private System.Windows.Forms.Button btnLiveBand;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Button Backbtn;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox PBSuites3;
        private System.Windows.Forms.PictureBox PBSuites2;
        private System.Windows.Forms.PictureBox PBSuites1;
        private System.Windows.Forms.PictureBox PBGown3;
        private System.Windows.Forms.PictureBox PBGown2;
        private System.Windows.Forms.PictureBox PBGown1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox PBShoes3;
        private System.Windows.Forms.PictureBox PBShoes2;
        private System.Windows.Forms.PictureBox PBShoes1;
        private System.Windows.Forms.PictureBox PBAccessories3;
        private System.Windows.Forms.PictureBox PBAccessories2;
        private System.Windows.Forms.PictureBox PBAccessories1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox16;
    }
}